package com.gameapps.phillip.singlethreadgame.sprite_definition;

/**
 * Created by user on 22/01/2017.
 */

public interface LosingNPCSprite {

    public boolean moveToMiddle();

}
