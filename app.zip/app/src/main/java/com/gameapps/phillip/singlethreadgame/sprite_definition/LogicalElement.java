package com.gameapps.phillip.singlethreadgame.sprite_definition;

/**
 * Created by Phillip on 1/4/2017.
 */

public interface LogicalElement extends Discardable {

    public void change();

}
