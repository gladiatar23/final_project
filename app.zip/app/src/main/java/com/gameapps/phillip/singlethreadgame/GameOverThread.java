package com.gameapps.phillip.singlethreadgame;

import com.gameapps.phillip.singlethreadgame.sprite_definition.LosingNPCSprite;
import com.gameapps.phillip.singlethreadgame.sprite_definition.Sprite;

/**
 * Created by user on 22/01/2017.
 */

public class GameOverThread extends Thread {

//    LosingNPCSprite loneSprite;
//
//    public GameOverThread(LosingNPCSprite loneSprite) {
//        this.loneSprite = loneSprite;
//    }
//
//    @Override
//    public void run() {
//        boolean isReachingMiddle = false;
//        do {
//            isReachingMiddle = loneSprite.moveToMiddle();
//        }while(!isReachingMiddle);
//
//
//
//    }
}
